import React from 'react';


export default function Products() {
  return <h1 className='products'>PRODUCTS</h1>;
}
