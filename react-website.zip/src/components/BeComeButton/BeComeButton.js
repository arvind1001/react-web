import React from 'react';
import btnlogo from '../../assets/images/btnlogo.jpg';
import './BeComeButton.scss';


const BeComeButton=()=> {
  return (
    <>
      <button id="btn-image"><img src={btnlogo}/><p><span>Become</span> <br/>Visionaire</p></button>

</>

  );
}

export default BeComeButton;
